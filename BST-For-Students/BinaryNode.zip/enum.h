enum Error_code { duplicate_error, not_present, success };
// short for enumeration. Means an ordered list. 
// Three data types 
// We check if their multiple numbers
enum Balance_factor { left_higher, equal_height, right_higher };